from flask import Flask,session,render_template,url_for,request
from flask_wtf import FlaskForm
from wtforms.fields.html5 import DateField
from wtforms import SelectField
from wtforms import StringField,validators
import folium
from folium import plugins
from craigslist import CraigslistHousing
import numpy as np
import pandas as pd
import plotly.plotly as py
import plotly.offline as offline
from plotly.graph_objs import *
import warnings
warnings.filterwarnings('ignore')

from datetime import date
import gmplot

app = Flask(__name__)
app.secret_key = "12345678"

#Method Area
def get_location(location,min_price,price_len,category):
	lat_list=[]
	long_list=[]
	price_list=[]
	url_list=[]
	name_list=[]
	result_dic={}
		
	
	results = cl.get_results(sort_by='newest', geotagged=True, limit = 50)	
	for result in results:
		if result['geotag']==None:continue
		lat_list.append(result['geotag'][0])
		long_list.append(result['geotag'][1])
		price_list.append(result['price'])
		url_list.append(result['url'])
		name_list.append(result['name'])

	lat_array=np.array(lat_list,float)
	long_array=np.array(long_list,float)
	price_array=np.array(price_list,str)
	url_array=np.array(url_list,str)
	name_array=np.array(name_list,str)		
	
	result_dic['lat'] = lat_array
	result_dic['long'] = long_array
	result_dic['price']=price_array
	result_dic['url'] = url_array
	result_dic['name'] = name_array
	houses_map=folium.Map(location=[lat_array.mean(),long_array.mean()],zoom_start=10)
	
	return(result_dic,houses_map)


def draw_cluster(result_dic,houses_map):
	marker_cluster = folium.MarkerCluster().add_to(houses_map)
	for i in range(min(len(result_dic['lat']),len(result_dic['long']))):
		folium.Marker([result_dic['lat'][i],result_dic['long'][i]],popup='Rent for {0},the information is {1}, the url is {2}'.format(result_dic['price'][i],result_dic['name'][i],result_dic['url'][i])).add_to(marker_cluster)
	houses_map.create_map('templates/locationmap_result.html')
	return None		

def draw_heatmap(result_dic,houses_map):
	houses_map.add_children(plugins.HeatMap([[result_dic['lat'][i],result_dic['long'][i]]for i in range(min(len(result_dic['lat']),len(result_dic['long'])))]))
	houses_map.create_map('templates/heatmap_result.html')
	return None 

def read_zhvi_data(datafile):
	nan_values = ['NaN']
	data = pd.read_csv(datafile,na_values=nan_values,dtype={'RegionName': str},index_col=1)
	data['RegionName'] = data['RegionName'].str.slice(0,5)
	del data['SizeRank']
	return data

#Form Area
class LocationmapForm(FlaskForm)：
		min_price=SelectField("Min Price",choices=[("1000","1000"),("1500","1500"),("2000","2000"),("2500","2500"),("3000","3000")])
		price_len=SelectField("Price Length",choices=[("500","500"),("1000","1000"),("2000","2000"),("2500","2500"),("3000","3000")])
		pic_type=SelectField('Picture Type',choices=[('cluster','cluster'),('heat','heat')])

###########################################
class lendUser(FlaskForm):
		ret=SelectField("Return",choices=[('<3%','<3%'),('5%','5%'),('7%','7%'),('9%','9%'),('>10%','>10%'),('default','default')])
		risk=SelectField("Risk Level",choices=[('low','low'),('mid','mid'),('high','high'),('default','default')])
		strats=SelectField("Investment Strategy",choices=[('minRisk','minRisk'),('highReturn','highReturn'),('maxSR','maxSR'),('default','default')])
		diversity=SelectField("Risk Level",choices=[('low','low'),('mid','mid'),('high','high'),('default','default')])
###########################################

		
class ZipcodeForm(FlaskForm):
	zipcode=StringField('Search Word',[validators.Length(min=0, max=25)])		


	
#Link Area
def get_homepage_links():
	return [ {"href":url_for('Overview'),"label":"Overviews"}, 
				{"href":url_for('Compare'),"label":"Compare"},
				]

def get_overview_links():
	return [ {"href":url_for('Locationmap'),"label":"location overview"}, 
				{"href":url_for('Pricemap'),"label":"price overview"}
				]


#Href Area
@app.route('/')
def home():
	session['data_loaded'] = True
	return render_template('home.html',links = get_homepage_links())
	
@app.route("/overview", methods=['GET','POST'])
def Overview():
	session['data_loaded']=True
	return render_template('overview.html',links=get_overview_links())


@app.route("/overview/locationmap", methods=['GET','POST'])
def Locationmap():
	form=LocationmapForm()
	if form.validate_on_submit():
		location = request.form.get('location')
		min_price = int(request.form.get('min_price'))
		price_len=int(request.form.get('price_len'))
		category=request.form.get('category')
		pic_type = request.form.get('pic_type')
		if category=='Have broker fees':category='fee'
		else: category=='nfb'
		result_dic,houses_map=get_location(location,min_price,price_len,category)
		if pic_type=="cluster":
			draw_cluster(result_dic,houses_map)
			return render_template('map_result.html',mapfile='locationmap_result.html')
		else:
			draw_heatmap(result_dic,houses_map)
			return render_template('map_result.html',mapfile='heatmap_result.html')	
	return render_template('locationmapparams.html',form=form)

@app.route('/overview/pricemap',methods=['GET','POST'])
def Pricemap():
	session['pic_name']=''
	form=PricemapForm()
	if form.validate_on_submit():
		type = request.form.get('pic_type')
		bed_number=request.form.get('bed_number')
		session['pic_name']=type+" "+bed_number+'.png'
		return render_template('pricemap_result.html')
	return render_template('pricepaparams.html',form=form)


@app.route("/overview/recommendation", methods=['GET','POST'])
def lendrecommend():
	session['pic_name']=''
	form=lendUser()
	if form.validate_on_submit():
		ret = request.form.get('ret')
		risk = request.form.get('risk')
		strats = request.form.get('strats')
		diversity = request.form.get('diversity')
		session['pic_name']=ret+" "+risk+" "+strats+" "+diversity+'.png'
		return render_template('lending_result.html')
	return render_template('lending_all.html',form=form)		

	
@app.route("/compare", methods=['GET','POST'])
def Compare():
	session['data_loaded']=True
	return render_template('compare.html',links=get_compare_links())

@app.route("/compare/borough", methods=['GET','POST'])
def borough():
	df=pd.read_csv('files/ValueAnalysis.csv')
	data=df.groupby('Borough')
	data_list = list(data)
	borough_list=[]
	for i in range (len(data_list)):
		borough_list.append(data_list[i][0])
	size_list=list(data.size())
	
	zip_code=list(df['ZipCode'])
	borough_count={}
	borough_name=[]
	time_ave=list(df['Average price'])
	borough_count={'Bronx':0,'Brooklyn':0,'Queens':0,'Manhattan':0,'Staten Island':0}
	count={'Bronx':0,'Brooklyn':0,'Queens':0,'Manhattan':0,'Staten Island':0}
	for i in range(len(zip_code)):
		if bool(df.loc[i]['Borough']):
			borough_count[df.loc[i]['Borough']]+=df.loc[i]['Average price']
			count[df.loc[i]['Borough']]+=1
	for key in borough_count:
		if count[key]:
			borough_count[key]=borough_count[key]/count[key]
	
	borough_avevalue_all_home=list(borough_count.values())
	bo_name=list(borough_count.keys())
	df2=pd.DataFrame({'Borough':bo_name,'Average price':borough_avevalue_all_home})
	ave_frame=df2.set_index(df2['Borough'])
	
	ave_value=list(ave_frame['Average price'])
	borough=list((ave_frame['Borough']))
	
	offline.plot({'data': [Pie(labels=borough,values = ave_value,opacity=0.9) ],
                  'layout':Layout(title='Average Value of Different Borough')},filename='templates/borough1',auto_open=False)
				  
	offline.plot({'data': [Bar(x = borough, y = ave_value) ],
               'layout':Layout(title='Average Value of Different Borough',xaxis = XAxis(title = 'Different Borough'), yaxis = YAxis(title = 'Average Value'))},filename='templates/borough2',auto_open=False)

	offline.plot({'data': [Bar(x = borough_list, y = size_list) ],
                  'layout':Layout(title='Housing Frequency of Different Borough',xaxis = XAxis(title = 'Borough Name'), yaxis = YAxis(title = 'Frequency'))},filename='templates/borough3',auto_open=False)
	return render_template('borough_result.html',mapfile1='borough1.html',mapfile2='borough2.html',mapfile3='borough3.html')

@app.route("/compare/zipcode", methods=['GET','POST'])	
def zipcode():
	data_files=[
    'files/Zip_MedianRentalPricePerSqft_1Bedroom_clean.csv',
    'files/Zip_MedianRentalPricePerSqft_2Bedroom_clean.csv',
    'files/Zip_MedianRentalPricePerSqft_3Bedroom_clean.csv',
    'files/Zip_MedianRentalPricePerSqft_AllHomes_clean.csv',
    'files/Zip_MedianRentalPricePerSqft_CondoCoop_clean.csv',
    'files/Zip_MedianRentalPricePerSqft_Studio_clean.csv',
    'files/Zip_MedianRentalPricePerSqft_DuplexTriplex_clean.csv']

	for i in range(len(data_files)):
		raw_room_data = read_zhvi_data(data_files[i])
		raw_room_data['mean'] = raw_room_data.mean(axis = 1)
		room_data = pd.DataFrame()
		room_data['Zip Code'] = raw_room_data['RegionName']
		room_data[room_type[i]] = raw_room_data['mean']
		data = room_data if data is None else data.merge(room_data, on = 'Zip Code', how = 'left')
	
	session['pic_name']=''
	form=ZipcodeForm()
	if form.validate_on_submit():
		zip_code=request.form.get('zipcode')
		if zip_code not in zip_code_list:
			if zip_code =='All':
				session['pic_name']='zipcode All.png'
				return render_template('All_result.html')
			else:
				session['pic_name']='Error.png'
				return render_template('error_result.html')
		else:
			data_row = {}
			data_row[zip_code]=data.loc[data['Zip Code']==zip_code]
			del data_row[zip_code]['Zip Code']
	
			data_dict = data_row[zip_code].to_dict()
			for (k, v) in data_dict.items():
				data_dict[k] = 0 if np.isnan(list(v.values())[0]) else list(v.values())[0]
			offline.plot({'data': [Bar(x = room_type, y = [data_dict.get(k) for k in room_type]) ],
                  'layout':Layout(xaxis = XAxis(title = zip_code), yaxis = YAxis(title = 'Rental Price Per Square Feet', type = 'log'))},filename='templates/zipcode_output',auto_open=False)
			return render_template('zipcode_result.html',mapfile='zipcode_output.html')
	return render_template("zipcodeparams.html",form=form)

if __name__ == "__main__":
	app.run(debug = True)